# Phase 1: Database & ORM Setup
*Posted: April 8, 2025*

## Today's Goals
- [x] Set up PostgreSQL database on AWS RDS (t2.micro instance)
- [x] Configure connection pooling
- [x] Implement TypeORM with TypeScript
- [x] Create database migration scripts
- [x] Define core entity models with proper relationships

## What I Accomplished

Today I completed the database and ORM setup for our e-commerce API. I implemented TypeORM with TypeScript in strict mode and set up all necessary entity models with proper relationships. I also created scripts for migrations and database seeding, and added a custom "is_new" field to products that's automatically calculated based on creation date.

### Technical Details

I used TypeORM with PostgreSQL, setting up five main entities: User, Product, Order, OrderProduct, and Payment. All entities include proper relationships and TypeScript type definitions. For example, the Product entity has a virtual `isNew` property that's calculated based on its creation date:

```typescript
@Entity({ name: 'products' })
export class Product {
  // ... other properties
  
  @Column({ name: 'is_new', type: 'boolean', default: true })
  isNew!: boolean;
  
  @AfterLoad()
  updateIsNew(): void {
    const now = new Date();
    const thirtyDaysAgo = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000);
    this.isNew = this.createdAt > thirtyDaysAgo;
  }
}
```

I also implemented repositories for each entity that encapsulate common database operations, such as finding products by category or retrieving a user's active order:

```typescript
export class OrderRepository extends Repository<Order> {
  async findUserActiveOrder(userId: number): Promise<Order | null> {
    return this.findOne({
      where: { 
        userId, 
        status: OrderStatus.ACTIVE 
      },
      relations: ['orderProducts', 'orderProducts.product']
    });
  }
}
```

## Challenges Faced

Working with TypeScript in strict mode posed some challenges, particularly with property initialization in entity classes. Additionally, I encountered issues with TypeORM's migration system, which had trouble with an existing database schema.

### How I Solved Them

For the TypeScript strict mode issues, I implemented the definite assignment assertion operator (`!`) for required properties and used optional properties (`?`) for relationships. This satisfied TypeScript's strict property initialization requirements while maintaining compatibility with TypeORM.

For the migration issues, I created a direct database setup script that bypasses TypeORM's migration system for the initial setup. This script executes raw SQL in a transaction to create all tables, constraints, and seed data in one go.

## Key Learnings

- TypeORM and TypeScript strict mode require careful handling of property initialization
- Using repository pattern with TypeORM provides a clean abstraction for database operations
- Connection pooling is crucial for AWS RDS performance optimization
- Entity lifecycle hooks (like @AfterLoad) are powerful for calculated properties
- Direct SQL execution can sometimes be more reliable than ORM migrations for initial setup

## Next Steps

Now that the database and ORM setup is complete, I'll focus on:
1. Implementing Express controllers for API endpoints
2. Setting up JWT authentication
3. Adding request validation with Zod
4. Creating services for business logic
5. Implementing error handling middleware

## Resources Used
- [TypeORM Documentation](https://typeorm.io/)
- [PostgreSQL Documentation](https://www.postgresql.org/docs/)
- [AWS RDS Documentation](https://docs.aws.amazon.com/rds/)
- [TypeScript Handbook](https://www.typescriptlang.org/docs/handbook/intro.html)

---

*Notes for future blog post:*
- Highlight the automatic "is_new" calculation as a unique feature
- Create a diagram of entity relationships for visual learners
- Include performance metrics and benefits of connection pooling

---

*Tags: #TypeScript #AWS #PostgreSQL #TypeORM #DatabaseDesign #Phase1*