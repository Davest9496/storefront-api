# LinkedIn Dev Diary Template (In-Progress Posts)

**Title/Hook (Optional):**  
*Tried Supabase Auth Today… and hit a wall.*

**Project Snapshot:**  
> Day 4: Working on my personal finance tracker app with React & Supabase.

**What I Worked On:**  
> Today I focused on setting up user authentication and ensuring protected routes worked.

**Challenges Encountered:**  
> I discovered an issue with Supabase’s redirect URIs not working locally.

**How I Solved It / What I Learned:**  
> Realized I needed to whitelist `http://localhost:3000` in the Supabase dashboard—classic oversight!

**Call to Action/Engagement:**  
> How do you handle auth flows in your projects? Supabase, Firebase, or your own implementation?  
>  
**Hashtags:**  
> `#buildinpublic #webdev #react #supabase #devdiary`