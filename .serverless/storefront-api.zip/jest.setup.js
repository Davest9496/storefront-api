/* eslint-disable */
process.env.NODE_ENV = 'test';
require('dotenv').config({ path: '.env.test' });
jest.setTimeout(30000);
