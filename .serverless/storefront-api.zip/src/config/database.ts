import { AppDataSource, initializeDatabase } from './data-source';

export { initializeDatabase };

export default AppDataSource;
