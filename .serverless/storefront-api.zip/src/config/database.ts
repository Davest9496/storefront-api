import AppDataSource from './data-source';
export default AppDataSource;
